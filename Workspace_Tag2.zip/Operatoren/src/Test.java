
public class Test {

	public static void main(String[] args) {
		int x = 5, y = 2;
		double erg = 5 / 2.0;
		System.out.println(erg);

	}

}
