import java.util.Scanner;

public class Start {

	public static void main(String[] args) {
		
		sayHello();
		greetings("Hans");
		System.out.println("weitere Anweisungen");
		
		sayHello();
		greetings("Willi");
		System.out.println("neue Anweisungen");

		sayHello();
		double ergebnis = add(3.5, 6.7);
		System.out.println(ergebnis);
		
		System.out.println(concat("Hallo", " Welt"));
	}
	
	public static void sayHello() {
		for(int zaehler = 1; zaehler <=10; ++zaehler) {
			System.out.println("Hallo");
		}
	}
	
	public static void greetings(String name) {
		System.out.println("Hallo " + name);
		return;
	}
	
	public static double add(double wert1, double wert2) {
		double erg = wert1 + wert2;
		return erg;
	}
	
	public static String concat(String s1, String s2) {
		return s1 + s2;
	}

	public static Scanner createScanner() {
		return new Scanner(System.in);
	}
}
