
public class Fahrzeug {
	private String farbe;
	private String marke;
	private String art;
	private int ps;
	private int umdrehung;
	
	public void fahren() {
		System.out.println(marke + " f�hrt");
	}

	public int getPs() {
		return ps;
	}
	
	public void setPs(int p) {
		if(p <= 0 || p > 1000 ) {
			System.out.println("ung�ltiger Wert f�r ps: " + p);
			return;
		}
		ps = p;
	}
}
