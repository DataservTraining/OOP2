
public class Start {

	public static void main(String[] args) {
		int       x      = 10;
		Fahrzeug audi = new Fahrzeug();
//		audi.farbe = "Blau";
//		audi.art = "Kombi";
//		audi.marke = "Audi";
		audi.setPs(180);
//		audi.umdrehung = 0;
//		
//		System.out.println("Farbe vom Audi: " + audi.farbe);
//		System.out.println("Art vom Audi: " + audi.art);
//		System.out.println("Marke vom Audi: " + audi.marke);
		System.out.println("PS vom Audi: " + audi.getPs());
//		System.out.println("Umdrehungen vom Audi: " + audi.umdrehung);
		
//
//		Fahrzeug bmw = new Fahrzeug();
//		
//		bmw.marke = "BMW";
//		bmw.art = "Cabrio";
//		bmw.farbe = "Rot";
//		bmw.ps = 180;
//		bmw.umdrehung = 0;
//		
//		System.out.println("Farbe vom BMW: " + bmw.farbe);
//		System.out.println("Art vom BMW: " + bmw.art);
//		System.out.println("Marke vom BMW: " + bmw.marke);
//		System.out.println("PS vom BMW: " + bmw.ps);
//		System.out.println("Umdrehungen vom BMW: " + bmw.umdrehung);
	}

}
