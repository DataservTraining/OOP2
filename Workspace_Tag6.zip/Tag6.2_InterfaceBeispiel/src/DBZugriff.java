import java.sql.SQLException;

public interface DBZugriff {
	public void speichernPerson(Person p) throws SQLException;
	public Person suchePerson(int key);
}
