import java.sql.SQLException;

public class OracleDB implements DBZugriff{

	@Override
	public void speichernPerson(Person p) throws SQLException {
		System.out.println(p.getVorname() + " auf Oracle-DB gespeichert");
		
	}

	@Override
	public Person suchePerson(int key) {
		// TODO Auto-generated method stub
		return new Person("Oracle", "Zugriff", 0);
	}

}
