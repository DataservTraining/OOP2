import java.sql.SQLException;

public class Start {

	public static void main(String[] args) throws SQLException {
		Person willi = new Person("Wuff", "Willi", 10);
		willi.show();
		DBZugriff db = new OracleDB();
		db.speichernPerson(willi);
		
		Person neu = db.suchePerson(1);
		neu.show();
	}

}
