import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class MySQLDB implements DBZugriff{

	@Override
	public void speichernPerson(Person p) throws SQLException {
//		Connection con = null;  // Verbindung zur Datenbank aufbauen
//		Statement stmt = con.createStatement(); // Anweisung f�r Datenbankzugriff erzeugen
//		stmt.executeUpdate("insert into personen values ('Willi', 'Wuff', 10)"); //SQL-Anweisung zur DB schicken
		System.out.println(p.getVorname() + " auf MySQL gespeichert");
	}

	@Override
	public Person suchePerson(int key) {
		// TODO Auto-generated method stub
		return new Person("MySQL", "Zugriff", 0);
	}

}
