import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.sql.SQLException;

public class DateiDB implements DBZugriff{

	@Override
	public void speichernPerson(Person p) throws SQLException {
		System.out.println(p.getVorname() + " in Datei gespeichert");
		try {
			ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("personen.dat", true));
			out.writeObject(p);
			out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public Person suchePerson(int key) {
		
		return new Person("Datei", "Zugriff", 0);
	}

}
