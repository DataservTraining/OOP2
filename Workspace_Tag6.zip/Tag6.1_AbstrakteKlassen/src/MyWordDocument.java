
public class MyWordDocument extends AbstractDocument{

	@Override
	public void save() {
		System.out.println("MyWordDocument gespeichert");
	}

}
