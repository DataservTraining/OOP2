
public class Start {

	public static void main(String[] args) {
		AbstractApplication word = new MyWordApplication();
		word.newDocument();

	}

}
