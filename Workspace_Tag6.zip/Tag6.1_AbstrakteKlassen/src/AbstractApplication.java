
public abstract class AbstractApplication {
	private AbstractDocument[] documents;
	private int index;
	
	public AbstractApplication() {
		documents = new AbstractDocument[10];
	}
	
	public AbstractDocument newDocument() {
		AbstractDocument doc = null;
		if(index < documents.length) {
			doc = createDocument();
			documents[index] = doc;
			++index;
			doc.save();
		} else {
			System.out.println("es k�nnen keine weiteren Dokumente angelegt werden");
		}
		
		return doc;
	}
	
	public abstract AbstractDocument createDocument();

}
