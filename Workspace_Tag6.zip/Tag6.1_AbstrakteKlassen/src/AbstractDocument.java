
public abstract class AbstractDocument {
	public abstract void save();
}
