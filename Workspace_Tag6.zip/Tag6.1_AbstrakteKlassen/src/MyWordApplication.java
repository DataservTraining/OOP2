
public class MyWordApplication extends AbstractApplication{

	@Override
	public AbstractDocument createDocument() {
		return new MyWordDocument();
	}
	
}
