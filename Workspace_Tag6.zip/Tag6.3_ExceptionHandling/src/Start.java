import java.util.Scanner;

public class Start {

	public static void main(String[] args) {
		int wert1 = 9, wert2 = 0, erg;
		try {
		erg = wert1 / wert2;
		System.out.println("Hallo");
		System.out.println(erg);
		
		Scanner scanner = null;
		int zahl = scanner.nextInt();
		} catch(ArithmeticException e) {
			System.out.println("ArithmeticException");
			e.printStackTrace();
		} catch(NullPointerException e) {
			System.out.println("NullPointerException");
			e.printStackTrace();
		}
		
		System.out.println("Ende");
	}

}
