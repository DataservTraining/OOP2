import java.util.Random;

public class Start {

	public static void main(String[] args) {
		int[] zahlen = new int[4];
		zahlen[0] = 3;
		zahlen[1] = 5;
		zahlen[2] = 8;
		zahlen[3] = 10;
		
		for(int index = 0; index < 4; ++index) {
			zahlen[index] = (int)(Math.random() * 50 + 1);
		}
		
		
		for(int index = 0; index < 4; ++index) {
			System.out.println(zahlen[index]);
		}
//		System.out.println(zahlen[0]);
//		System.out.println(zahlen[1]);
//		System.out.println(zahlen[2]);
//		System.out.println(zahlen[3]);

		int[][] punkte = new int[3][2];
		punkte[0][0] = 2;
		punkte[0][1] = 2;
		punkte[1][0] = 3;
		punkte[1][1] = 1;
		punkte[2][0] = 7;
		punkte[2][1] = 10;
		
		for(int zeile = 0; zeile < 3; ++zeile) {
			for(int spalte = 0; spalte < 2; ++spalte) {
				System.out.print(punkte[zeile][spalte] + "\t");
			}
			System.out.println();
		}
		
	}

}
