
public class Adresse {
	private String strasse;
	private String ort;
	private String land;
	private int hausnummer;
	
	
	public Adresse() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Adresse(String strasse, String ort, String land, int hausnummer) {
		super();
		this.strasse = strasse;
		this.ort = ort;
		this.land = land;
		this.hausnummer = hausnummer;
	}
	public String getStrasse() {
		return strasse;
	}
	public void setStrasse(String strasse) {
		this.strasse = strasse;
	}
	public String getOrt() {
		return ort;
	}
	public void setOrt(String ort) {
		this.ort = ort;
	}
	public String getLand() {
		return land;
	}
	public void setLand(String land) {
		this.land = land;
	}
	public int getHausnummer() {
		return hausnummer;
	}
	public void setHausnummer(int hausnummer) {
		this.hausnummer = hausnummer;
	}
	
	
	
}
