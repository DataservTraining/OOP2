package application;

public class Person {
	private String name;
	private String vorname;
	private int alter;
	private static int anzahlPersonen;
	
	public Person() {
		this("unbekannt", "unbekannt", 0);
	}
	
	public Person(String name, String vorname) {
		this(name, vorname, 0);
	}

	public Person(String name, String vorname, int alter) {
		setName(name);
		setVorname(vorname);
		setAlter(alter);
		++anzahlPersonen;
	}

	public static int getAnzahlPersonen() {
		return anzahlPersonen;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getVorname() {
		return vorname;
	}
	public void setVorname(String vorname) {
		this.vorname = vorname;
	}
	public int getAlter() {
		return alter;
	}
	public void setAlter(int alter) {
		if(alter < 0) {
			System.out.println("ung�ltiges Alter: " + alter);
			return;
		}
		this.alter = alter;
	}
	
	public void show() {
		System.out.println("Name:  " + vorname + " " + name);
		System.out.println("Alter: " + alter);
	}

	@Override
	protected void finalize() throws Throwable {
		--anzahlPersonen;
	}
	
	
}
