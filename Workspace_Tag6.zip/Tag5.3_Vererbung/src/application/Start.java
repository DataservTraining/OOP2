package application;

public class Start {

	public static void main(String[] args) throws InterruptedException {
		System.out.println("Anzahl Personen: " + Person.getAnzahlPersonen());
		
		Person willi = new Person("Willi", "Wuff", 15);
		System.out.println("Anzahl Personen: " + Person.getAnzahlPersonen());
		willi.show();
		
		Mitarbeiter ma1 = new Mitarbeiter("Donald", "Duck", 10, 
									1010, 20, 1204.67);
		System.out.println("Anzahl Personen: " + Person.getAnzahlPersonen());
		ma1.show();
		
		Person mitarbeiter = ma1;
		System.out.println("===========================");
		mitarbeiter.show();
		
		mitarbeiter = willi;
		System.out.println("===========================");
		mitarbeiter.show();
		
		willi = null;
		System.gc();
		Thread.sleep(50);
		System.out.println("Anzahl Personen: " + Person.getAnzahlPersonen());
		mitarbeiter = null;
		System.gc();
		Thread.sleep(50);
		System.out.println("Anzahl Personen: " + Person.getAnzahlPersonen());
		ma1 = null;
		System.gc();
		Thread.sleep(50);
		System.out.println("Anzahl Personen: " + Person.getAnzahlPersonen());

	}

}
