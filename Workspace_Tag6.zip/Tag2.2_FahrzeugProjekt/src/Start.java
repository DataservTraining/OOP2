import application.Fahrzeug;

public class Start {

	public static void main(String[] args){
		int       x      = 10;

		Fahrzeug audi = new Fahrzeug();
		
		audi.setFarbe("Blau");
		audi.setArt("Kombi");
		audi.setMarke("Audi");
//		audi.ps = ;
		
		audi.setPs(180);
		audi.setUmdrehung(0);
		
		System.out.println("Farbe vom Audi: " + audi.getFarbe());
//		System.out.println("Art vom Audi: " + audi.art);
//		System.out.println("Marke vom Audi: " + audi.marke);
		System.out.println("PS vom Audi: " + audi.getPs());
//		System.out.println("Umdrehungen vom Audi: " + audi.umdrehung);
		

		Fahrzeug bmw = new Fahrzeug("Rot", "BMW", "Cabrio", 180, 0);
		
//		bmw.setMarke("BMW");
//		bmw.setArt("Cabrio");
//		bmw.setFarbe("Rot");
//		bmw.setPs(180);
//		bmw.setUmdrehung(0);
		
		System.out.println("Farbe vom BMW: " + bmw.getFarbe());
		System.out.println("Art vom BMW: " + bmw.getArt());
		System.out.println("Marke vom BMW: " + bmw.getMarke());
		System.out.println("PS vom BMW: " + bmw.getPs());
		System.out.println("Umdrehungen vom BMW: " + bmw.getUmdrehung());
	}

}
