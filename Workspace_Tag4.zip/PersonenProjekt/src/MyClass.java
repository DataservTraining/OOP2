
public class MyClass {

	public static void main(String[] args) {
		Person person1 = new Person();
		System.out.println(person1.vorname);
		System.out.println(person1.name);
		System.out.println("===========================");
		Person person2 = new Person("Hansen");
		
		System.out.println(person2.vorname);
		System.out.println(person2.name);
		
		System.out.println("===========================");
		
		Person person3 = new Person("Doe", "Jane");
		
		System.out.println(person3.vorname);
		System.out.println(person3.name);

	}

}
