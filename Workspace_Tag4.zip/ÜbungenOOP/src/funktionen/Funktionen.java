package funktionen;

public class Funktionen {
	// 2,5� = 6,25
	
	/*
	 * p = potenzieren(2, 4)
	 * print("2 ^ 4 = " + p)
	 * 
	 * p = potenzieren(2.5, 2)
	 * print("2,5 ^ 2 = " + p) 
	 */
	
	public static void main(String[] args) {
		double b = 2;
		int e = 4;
		double p = potenzieren(b, e);
		System.out.println("2 ^ 4 = " + p);
		b = 2.5;
		e = 2;
		p = potenzieren(b, e);
		System.out.println("2,5 ^ 2 = " + p);

	}

	/*
	 * def potenzieren(basis, exponent):
	 * 		potenz = 1
	 *      for i in range(1, exponent+1):
	 *            potenz = potenz * basis
	 *      return potenz
	 */
	
	public static double potenzieren(double basis, int exponent) {
		double potenz = 1;
		// basis * basis * basis sooft wie exponent
		for(int i = 1; i <= exponent; ++i) {
			potenz *= basis; // potenz = potenz * basis;
		}
		return potenz;
	}
}
