package uebung5_11;

import java.util.Scanner;

public class Aufgabe2 {

	public static void main(String[] args) {
		int x = 10;
		int punkte;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Punktzahl? ");
		punkte = scanner.nextInt();
		
		if(punkte >=7 && punkte <= 10) {
			System.out.println("bestanden");
		} else if(punkte >= 0 && punkte <= 6) {
			System.out.println("nicht bestanden");
		} else {
			System.out.println("ung�ltige Punktzahl");
		}
		scanner.close();

	}

}
