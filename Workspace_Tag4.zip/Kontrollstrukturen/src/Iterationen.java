import java.util.Scanner;

public class Iterationen {

	public static void main(String[] args) {
		//Z�hlergesteuerte Schleife
		/*
		 * for i in range(1, 30, 1)
		 */
		for( int zaehler = 1; zaehler <= 30; ++zaehler) {
			
			System.out.println("Z�hlerstand: " + zaehler);
		}

//		int x;
//		
//		System.out.println("Bitte Zahl eingeben: ");
//		Scanner scanner = new Scanner(System.in);
//		x = scanner.nextInt();
//		int y = 0;
//		while(y < x) {
//			
//			System.out.println(y + " < " + x);
//			++y;
//		}
//		
//		System.out.println("Bitte Zahl eingeben: ");
//		x = scanner.nextInt();
//		y = 0;
//		do {
//			System.out.println(y + " < " + x);
//			++y;	
//		}while (y < x);
//		
//		double summe= 0;
//		int zaehler = 0;
//		int zahl = 0;
//		
//		do {
//			System.out.println("Bitte Zahl eingeben: ");
//			zahl = scanner.nextInt();
//			if(zahl != 0) {
//				++zaehler;
//			}
//			summe += zahl;
//		}while (zahl != 0);
//		
//		System.out.println("Summe: " + summe);
//		if(zaehler != 0) {
//			System.out.println("Mittelwert: " + (summe/zaehler));
//		}
//		
//		summe = 0;
//		zaehler = 0;
//		System.out.println("Bitte Zahl eingeben: ");
//		zahl = scanner.nextInt();
//		
//		while(zahl != 0) {
//			++zaehler;
//			summe += zahl;
//			System.out.println("Bitte Zahl eingeben: ");
//			zahl = scanner.nextInt();
//		}
//		System.out.println("Summe: " + summe);
//		if(zaehler != 0) {
//			System.out.println("Mittelwert: " + (summe/zaehler));
//		}
		
	}

}
