package encoding;

import java.io.PrintStream;
import java.io.UnsupportedEncodingException;

public class EncodingFactory {
	
	public static void setUTF_8Encoding() {
		try {
			System.setOut(new PrintStream(System.out, true, "UTF-8"));
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}
}
