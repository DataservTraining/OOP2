
public class Rechteck {
	// Attribute
//  Sichtbarkeit   Datentyp    Attributsname
	private         double       laenge;
	private         double       hoehe;
	
	// Standardkonstruktor
//  Sichtbarkeit   kein R�ckgabetyp!   Methodenname  Parameterliste
	public                              Rechteck        () {
		this(1, 1);
	}
	
	public Rechteck(double seitenlaenge) {
		this(seitenlaenge, seitenlaenge);
//		this.laenge = seitenlaenge;
//		this.hoehe = seitenlaenge;
	}
	
	public Rechteck (double laenge, double hoehe) {
		setLaenge(laenge);
		setHoehe(hoehe);
//		this.laenge = laenge;
//		this.hoehe = hoehe;
	}
	
//  Sichtbarkeit   R�ckgabetyp   Methodenname  Parameterliste
	public          double        getLaenge     (           ) 
	// Methodenrumpf Beginn
	{
		return laenge;
	} // Methodenrumpf Ende
	
//  Sichtbarkeit   R�ckgabetyp   Methodenname       Parameterliste
	                                          //  Typ    Parametername
	public          void        setLaenge     ( double        laenge  ) 
	// Methodenrumpf Beginn
	{
		if(laenge < 0) {
			System.out.println("ung�ltiger Wert f�r die L�nge: " + laenge);
			return;
		}
		this.laenge = laenge;
	} // Methodenrumpf Ende
	
	public double getHoehe() {
		return hoehe;
	}
	
	public void setHoehe(double hoehe) {
		if(hoehe < 0) {
			System.out.println("ung�ltiger Wert f�r die H�he: " + hoehe);
			return;
		}
		this.hoehe = hoehe;
	}
}
