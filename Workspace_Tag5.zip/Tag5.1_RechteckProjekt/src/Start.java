
public class Start {

	public static void main(String[] args) {
		Rechteck r1 = new Rechteck();
		System.out.println("L�nge von r1: " + r1.getLaenge());
		System.out.println("H�he von r1: " + r1.getHoehe());
		
		Rechteck r2 = new Rechteck(2.5);
		System.out.println("L�nge von r2: " + r2.getLaenge());
		System.out.println("H�he von r2: " + r2.getHoehe());
		
		Rechteck r3 = new Rechteck(3.4, 6.7);
		System.out.println("L�nge von r3: " + r3.getLaenge());
		System.out.println("H�he von r3: " + r3.getHoehe());

	}

}
