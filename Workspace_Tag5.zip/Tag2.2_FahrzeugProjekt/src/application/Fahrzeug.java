package application;
public class Fahrzeug {
	private String farbe;
	private String marke;
	private String art;
	private int ps;
	private int umdrehung;
	
	public Fahrzeug() {
		this("unbekannt", "unbekannt", "unbekannt", 0, 0);
	}
	
	
	
	public Fahrzeug(String farbe, String marke, String art, 
					int ps, int umdrehung) {
		this.farbe = farbe;
		this.marke = marke;
		this.art = art;
		this.ps = ps;
		this.umdrehung = umdrehung;
	}



	public void fahren() {
		System.out.println(marke + " f�hrt");
	}

	public int getPs() {
		return ps;
	}
	
	public void setPs(int ps) {
		if(ps <= 0 || ps > 1000 ) {
			System.out.println("ung�ltiger Wert f�r ps: " + ps);
			return;
		}
		this.ps = ps;
	}

	public String getFarbe() {
		return this.farbe;
	}

	public void setFarbe(String farbe) {
		if(farbe == null) {
			System.out.println("Farbe darf nicht null sein");
			return;
		}
		this.farbe = farbe;
	}

	public String getMarke() {
		return marke;
	}

	public void setMarke(String marke) {
		if(marke == null) {
			System.out.println("Marke darf nicht null sein");
			return;
		}
		this.marke = marke;
	}

	public String getArt() {
		return art;
	}

	public void setArt(String art) {
		if(art == null) {
			System.out.println("Art darf nicht null sein");
			return;
		}
		this.art = art;
	}

	public int getUmdrehung() {
		return umdrehung;
	}

	public void setUmdrehung(int umdrehung) {
		if(umdrehung < 0 || umdrehung > 10000) {
			System.out.println("ung�ltiger Wert f�r Umdrehungen: " + umdrehung);
		}
		this.umdrehung = umdrehung;
	}
	
	
}
