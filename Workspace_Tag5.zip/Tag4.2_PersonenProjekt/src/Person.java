
public class Person {
	public String vorname;
	public String name;
	
	public Person() {
		this("unbekannt", "unbekannt");
//		System.out.println("Standardkonstruktor!");
//		this.vorname = "unbekannt";
//		this.name = "unbekannt";
	}
	
	public Person(String name) {
		this(name, "unbekannt");
//		this.name = name;
//		this.vorname = "unbekannt";
	}
	
	public Person(String name, String vorname) {

		this.name = name;
		this.vorname = vorname;
	}
	
	
	public void essen() {
		System.out.println(vorname + "isst");
	}
}
