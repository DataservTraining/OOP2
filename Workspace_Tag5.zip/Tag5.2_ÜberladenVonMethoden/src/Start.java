
public class Start {

	public static void main(String[] args) {
		int ergInt = add(2, 5);
		System.out.println(ergInt);
		
		ergInt = add(2, 5, 6);
		System.out.println(ergInt);

		double ergDouble = add(3.4, 6.7);
		System.out.println(ergDouble);
		
		ergDouble = add(3, 6.7);
		System.out.println(ergDouble);
		
		
		ergDouble = add(3.4, 6);
		System.out.println(ergDouble);
		
		String ergString = add("Hallo", " Welt");
		System.out.println(ergString);
	}
	
	public static int add(int wert1, int wert2) {
		return wert1 + wert2;
	}
	public static int add(int wert1, int wert2, int wert3) {
		return wert1 + wert2 + wert3;
	}
	public static double add(double wert1, int wert2) {
		return wert1 + wert2;
	}
	
	public static double add(int wert1, double wert2) {
		return wert1 + wert2;
	}
	
	public static double add(double wert1, double wert2) {
		return wert1 + wert2;
	}
	
	public static String add(String text1, String text2) {
		return text1 + text2;
	}

}
