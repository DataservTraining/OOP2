package application;

public class Mitarbeiter extends Person{
	private int maNr;
	private int abtNr;
	private double gehalt;
	
	public Mitarbeiter() {
		this("unbekannt", "unbekannt", 0, 1000, 10, 1);
	}
	
	public Mitarbeiter(String name, String vorname, int alter, 
					   int maNr, int abtNr, double gehalt) {
		super(name, vorname, alter);
//		setName(name);
//		setVorname(vorname);
//		setAlter(alter);
		setMaNr(maNr);
		setAbtNr(abtNr);
		setGehalt(gehalt);
	}
	
	public int getMaNr() {
		return maNr;
	}
	public void setMaNr(int maNr) {
		if(maNr < 1000 || maNr > 10000) {
			System.out.println("ung�ltiger Wert f�r Mitarbeiternummer: " + maNr);
			return;
		}
		this.maNr = maNr;
	}
	public int getAbtNr() {
		return abtNr;
	}
	public void setAbtNr(int abtNr) {
		if(abtNr < 10 || abtNr > 100) {
			System.out.println("ung�ltiger Wert f�r Abteilungsnummer: " + abtNr);
			return;
		}
		this.abtNr = abtNr;
	}
	public double getGehalt() {
		return gehalt;
	}
	public void setGehalt(double gehalt) {
		if(gehalt <= 0) {
			System.out.println("ung�ltiger Wert f�r Gehalt: " + gehalt);
			return;
		}
		this.gehalt = gehalt;
	}
	
	
	
}
