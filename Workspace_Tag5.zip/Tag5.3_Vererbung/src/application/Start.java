package application;

public class Start {

	public static void main(String[] args) {
		Person willi = new Person("Willi", "Wuff", 15);
		willi.show();
		
		Mitarbeiter ma1 = new Mitarbeiter("Donald", "Duck", 10, 
									1010, 20, 1204.67);
		

	}

}
