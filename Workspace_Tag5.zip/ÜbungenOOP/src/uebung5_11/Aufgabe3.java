package uebung5_11;

import java.util.Scanner;

public class Aufgabe3 {

	public static void main(String[] args) {
		int punkte;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Punktzahl? ");
		punkte = scanner.nextInt();
		
		if(punkte >=7 && punkte <= 10) {
			switch(punkte) {
			case 10:
				System.out.print("sehr ");
			case 9:
				System.out.println("gut");
				break;
			case 8:
				System.out.println("befriedigend");
				break;
			case 7:
				System.out.println("ausreichend");
				break;
			}
		} else if(punkte >= 0 && punkte <=6) {
			System.out.println("leider nicht gen�gend Punkte");
		} else {
			System.out.println("ung�ltige Punktzahl");
		}

	}

}
