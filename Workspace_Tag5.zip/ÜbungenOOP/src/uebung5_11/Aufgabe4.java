package uebung5_11;

public class Aufgabe4 {

	public static void main(String[] args) {
		
		for(int zahl = 1; zahl <= 30; ++zahl) {
			if(zahl % 2 == 1) {
				System.out.println("odd " + zahl);
			}
		}
		
		System.out.println();

	}

}
