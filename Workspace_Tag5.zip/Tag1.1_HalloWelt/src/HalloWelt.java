
public class HalloWelt {
	public static void main(String[] args) {
		// Kommentar
		System.out.println("Hallo Welt");
	}
}
