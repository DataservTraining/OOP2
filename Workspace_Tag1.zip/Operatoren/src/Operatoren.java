
public class Operatoren {

	public static void main(String[] args) {
		//Arithmetische Operatoren
		// +, -, *, /, %
		int wert1 = 5, wert2 = 2;
		double erg;
		erg = wert1 % wert2;
		System.out.println(erg);
		
		// inkrement- und Dekrement-Operator
		// ++, --
		System.out.println(wert1++);
//		wert1++;
		System.out.println(wert1);
		
		// Relationale Operatoren
		// <, >, <=, >=, ==, !=
		
		// Logische Operatoren
		// && (and), || (or), ^ (xor), ! (not)
		
		boolean ok = wert1 < 10 ^ wert2 > 4;
		System.out.println(ok);
		
		// Zuweisungsoperatoren
		// =,+=, -=, *=, /=, %=, =. 
			wert1 = 6 + 8; // wert1 = wert1 * (6 + 8)
	}

}
