import java.util.Scanner;

public class Verzweigungen {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Bitte Punktzahl eingeben");
		int punkte = scanner.nextInt();
		
		switch(punkte) {
		case 10:
		case 9:
		case 8:
		case 7:
			System.out.println("bestanden");
			break;
		case 6:
		case 5:
		case 4:
		case 3:
		case 2:
		case 1:
			System.out.println("nicht bestanden");
			break;
		default:
			System.out.println("");
		}
		
		// einseitige Verzweigung
		/*
		 * if x == 1:
		 *       print(x)
		 */
		int x = 1;
		if (x == 1) {
			System.out.println("x ist gleich 1");
		}

		// zweiseitige Verzweigung
		/*
		 * if x == 1:
		 *       print(x)
		 * else:
		 *       print("x ungleich 1")
		 */
		if (x == 1) {
			System.out.println("x ist gleich 1");
		} else {
			System.out.println("x ungleich 1");
		}
		
		// mehrstufige Verzweigung
		/*
		 * if x == 1:
		 *       print(x)
		 * elif x == 0:
		 * 		 print(x == 0)
		 * else:
		 *       print("x ungleich 1")
		 */
		if (x == 1) {
			System.out.println("x ist gleich 1");
		} else if(x == 0){
			System.out.println("x == 0");
		}else {
			System.out.println("x ungleich 1");
		}
		
		int note = 3;
		
		/*if(note == 1) {
			
		} else if (note == 2) {
			
		}
		*/
		
		// mehrseitige Verzweigung
		
		switch(note) {
		case 1:
			System.out.println("sehr gut");
			break;
		case 2:
			System.out.println("gut");
			break;
		case 3:
			System.out.println("befriedigend");
			break;
		case 4:
			System.out.println("ausreichend");
			break;
		case 5:
			System.out.println("mangelhaft");
			break;
		case 6:
			System.out.println("ungen�gend");
			break;
		default:
			System.out.println("ung�ltige Note");
		}
		
		switch(note) {
		case 1:
		case 2:
		case 3:
		case 4:
			System.out.println("bestanden");
			break;
		case 5:
		case 6:
			System.out.println("nicht bestanden");
			break;
		default:
			System.out.println("ung�ltige Note");
		}

	}

}
