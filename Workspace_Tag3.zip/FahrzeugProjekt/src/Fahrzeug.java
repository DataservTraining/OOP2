
public class Fahrzeug {
	private String farbe;
	private String marke;
	private String art;
	private int ps;
	private int umdrehung;
	
	public void fahren() {
		System.out.println(marke + " f�hrt");
	}

	public int getPs() {
		return ps;
	}
	
	public void setPs(int p) {
		if(p <= 0 || p > 1000 ) {
			System.out.println("ung�ltiger Wert f�r ps: " + p);
			return;
		}
		ps = p;
	}

	public String getFarbe() {
		return farbe;
	}

	public void setFarbe(String f) {
		if(f == null) {
			System.out.println("Farbe darf nicht null sein");
			return;
		}
		farbe = f;
	}

	public String getMarke() {
		return marke;
	}

	public void setMarke(String m) {
		if(m == null) {
			System.out.println("Marke darf nicht null sein");
			return;
		}
		marke = m;
	}

	public String getArt() {
		return art;
	}

	public void setArt(String a) {
		if(a == null) {
			System.out.println("Art darf nicht null sein");
			return;
		}
		art = a;
	}

	public int getUmdrehung() {
		return umdrehung;
	}

	public void setUmdrehung(int u) {
		if(u < 0 || u > 10000) {
			System.out.println("ung�ltiger Wert f�r Umdrehungen: " + u);
		}
		umdrehung = u;
	}
	
	
}
