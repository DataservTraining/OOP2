
public class DatenTypen {
	public static void main(String[] args) {
		// Ganze Zahlen
		byte  erstesByte, zweitesByte;  // -128 bis 127
		short ersterShort;
		int ersterInt;
		long ersterLong;
		
		// Flie�kommazahlen
		float ersterFloat;
		double ersterDouble;
		
		char erstesZeichen;
		erstesZeichen = 'A';
		erstesZeichen = 65;
		System.out.println(erstesZeichen);
		
		boolean ok = true; // false 
	}
}
