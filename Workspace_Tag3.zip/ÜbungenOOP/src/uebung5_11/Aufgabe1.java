package uebung5_11;

import java.util.Scanner;

public class Aufgabe1 {

	public static void main(String[] args) {
		int punkte;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Punktzahl? ");
		punkte = scanner.nextInt();
		
		if(punkte >=7 && punkte <= 10) {
			System.out.println("bestanden");
		} else {
			System.out.println("nicht bestanden");
		}
		scanner.close();
	}

}
