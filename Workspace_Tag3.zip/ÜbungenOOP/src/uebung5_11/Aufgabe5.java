package uebung5_11;



public class Aufgabe5 {

	public static void main(String[] args) {
		for(int basis = 1; basis <= 15; ++basis) {
			System.out.println(basis + " * " + basis + " = " + (basis*basis));
		}

	}

}
